export const CAROUSEL_DATA = [
  {
    title: "Dark Maroon Zariwork Tissue Saree",
    urls: {
      SHORT:
        "https://www.koskii.com/cdn/shop/files/quinn_b4e15m93prwddg123qpgzi8c.mp4",
      POSTER:
        "https://www.koskii.com/cdn/shop/files/quinn_hfue58ecg89w4bq6855k1tae.jpg",
      STORY:
        "https://www.koskii.com/cdn/shop/files/quinn_x02dqum6iveufc0lz9so4ky1.jpg",
      FULL: "https://www.koskii.com/cdn/shop/files/quinn_zeb49eeixlihtd0rb7ltjib9.mp4",
    },
  },
  {
    title: "Rani Pink Threadwork Chiffon Saree",
    urls: {
      POSTER:
        "https://www.koskii.com/cdn/shop/files/quinn_fcgflxtzgu2j3sgztlgz81w0.jpg",
      SHORT:
        "https://www.koskii.com/cdn/shop/files/quinn_gxa1lcpjs0ks5vzgsqh8ho7c.mp4",
      STORY:
        "https://www.koskii.com/cdn/shop/files/quinn_aojgmo14ye30cknwitetcsjx.jpg",
      FULL: "https://www.koskii.com/cdn/shop/files/quinn_pi8y5sjhz0dx04r9yp3kklcd.mp4",
    },
  },
  {
    title: "Rani Pink Zariwork Semi Crepe Unstitched Salwar Suit",
    urls: {
      POSTER:
        "https://www.koskii.com/cdn/shop/files/quinn_xyojxkzx4s61mdtz4wa2knuj.jpg",
      SHORT:
        "https://www.koskii.com/cdn/shop/files/quinn_yos0sg4gohq9bzzuzr75jdfe.mp4",
      STORY:
        "https://www.koskii.com/cdn/shop/files/quinn_x54r685y3f7mwgauqscs3df5.jpg",
      FULL: "https://www.koskii.com/cdn/shop/files/quinn_xcwpsp4qh8yq5ip72l6dpu6p.mp4",
    },
  },
  {
    title: "Sky Blue Threadwork Tissue Saree",
    urls: {
      SHORT:
        "https://www.koskii.com/cdn/shop/files/quinn_xzklwkcpru5lyocgxsqn23jp.mp4",
      POSTER:
        "https://www.koskii.com/cdn/shop/files/quinn_zgcsjf48dns1jlrwo7zsyeuu.jpg",
      FULL: "https://www.koskii.com/cdn/shop/files/quinn_fqauvszkfb8sx0qwz479ijiw.mp4",
      STORY:
        "https://www.koskii.com/cdn/shop/files/quinn_jaz7j6kojm2mfu273nm47t0y.jpg",
    },
  },
  {
    title: "Peacock Blue Threadwork Raw Silk Readymade Salwar Suit",
    urls: {
      FULL: "https://www.koskii.com/cdn/shop/files/quinn_regnjeeyj931e5bui1i67it3.mp4",
      STORY:
        "https://www.koskii.com/cdn/shop/files/quinn_s3t9mo3nz0ftjthimzsgnq7p.jpg",
      SHORT:
        "https://www.koskii.com/cdn/shop/files/quinn_lac6jfj8beg745988yew2a6i.mp4",
      POSTER:
        "https://www.koskii.com/cdn/shop/files/quinn_i1qdm64m2jxfo8s7m255qibw.jpg",
    },
  },
  {
    title: "Grey Zariwork Tissue Saree",
    urls: {
      SHORT:
        "https://www.koskii.com/cdn/shop/files/quinn_zs1sms5ay922bh5hrwwbuk8m.mp4",
      FULL: "https://www.koskii.com/cdn/shop/files/quinn_zd3xcxxo78b8h5hm5u6vxisq.mp4",
      STORY:
        "https://www.koskii.com/cdn/shop/files/quinn_bntbwdvhbhorhvf1may4judz.jpg",
      POSTER:
        "https://www.koskii.com/cdn/shop/files/quinn_fos20e9w9zt1uv62n5xc3je9.jpg",
    },
  },
  {
    title: "Navy Blue Zariwork Art Silk Readymade Salwar Suit",
    urls: {
      SHORT:
        "https://www.koskii.com/cdn/shop/files/quinn_e05fkgo3ryjqv0mlekcg88st.mp4",
      FULL: "https://www.koskii.com/cdn/shop/files/quinn_izeuq4gcvwqf4r0nyeqv2gtt.mp4",
      STORY:
        "https://www.koskii.com/cdn/shop/files/quinn_pdvjqiis8lskpaoo7nv777yg.jpg",
      POSTER:
        "https://www.koskii.com/cdn/shop/files/quinn_daletkc3mrolxs47zgancs2p.jpg",
    },
  },
  {
    title: "Yellow Threadwork Semi Crepe Readymade Salwar Suit",
    urls: {
      STORY:
        "https://www.koskii.com/cdn/shop/files/quinn_dkf237mkoehw2ixx9nddyxpy.jpg",
      FULL: "https://www.koskii.com/cdn/shop/files/quinn_t4yeu1493fsp0smcrk4u1ceg.mp4",
      POSTER:
        "https://www.koskii.com/cdn/shop/files/quinn_j6yk3xzu60shnvb409v4yy3y.jpg",
      SHORT:
        "https://www.koskii.com/cdn/shop/files/quinn_hz8p5a03jhrnkssb44jzekbu.mp4",
    },
  },
  {
    title: "Pink Printed Satin Saree",
    urls: {
      POSTER:
        "https://www.koskii.com/cdn/shop/files/quinn_cfzdll2mowv9wgdlpsod05ga.jpg",
      SHORT:
        "https://www.koskii.com/cdn/shop/files/quinn_tol4wb18ifsp8cfyqs0h08aw.mp4",
      FULL: "https://www.koskii.com/cdn/shop/files/quinn_w2z84tmd2322uqds6bat99s0.mp4",
      STORY:
        "https://www.koskii.com/cdn/shop/files/quinn_dc72nene95nixmmwwis06tlv.jpg",
    },
  },
  {
    title: "Onion Pink Zariwork Tissue Saree",
    urls: {
      POSTER:
        "https://www.koskii.com/cdn/shop/files/quinn_dvy9qvqzqfzckjr8j1qv4zz9.jpg",
      STORY:
        "https://www.koskii.com/cdn/shop/files/quinn_x6yksbysjp82ooi65urxddy7.jpg",
      SHORT:
        "https://www.koskii.com/cdn/shop/files/quinn_e70gdyfnqymupge8ectxpi5v.mp4",
      FULL: "https://www.koskii.com/cdn/shop/files/quinn_pp7juki8bbxdgek2y7iz4bw4.mp4",
    },
  },
  {
    title: "Peacock Blue Stonework Chiffon Saree",
    urls: {
      STORY:
        "https://www.koskii.com/cdn/shop/files/quinn_fudtbef8hks8o15o2ykazxvr.jpg",
      FULL: "https://www.koskii.com/cdn/shop/files/quinn_v3ksyqz0ifj5n127k8sy1cxp.mp4",
      SHORT:
        "https://www.koskii.com/cdn/shop/files/quinn_mbwwc89m32331lsa8fxxaugo.mp4",
      POSTER:
        "https://www.koskii.com/cdn/shop/files/quinn_jd5iy8em038npx0qfagaib2w.jpg",
    },
  },
  {
    title: "Navy Blue Swarovski Semi Crepe Designer Saree",
    urls: {
      SHORT:
        "https://www.koskii.com/cdn/shop/files/quinn_t32uuhxkdsw44jxao3ifkisl.mp4",
      POSTER:
        "https://www.koskii.com/cdn/shop/files/quinn_jxvnmueeg8x7dy83s4mvwizz.jpg",
      STORY:
        "https://www.koskii.com/cdn/shop/files/quinn_zf9hnrzvlzgvxa5m7uu4j3tx.jpg",
      FULL: "https://www.koskii.com/cdn/shop/files/quinn_k52rnhch67665e8qzv60serw.mp4",
    },
  },
  {
    title: "Wine Swarovski Semi Crepe Designer Saree",
    urls: {
      POSTER:
        "https://www.koskii.com/cdn/shop/files/quinn_b5lPDQnOL0jqSww3NS1wf.jpg",
      SHORT:
        "https://www.koskii.com/cdn/shop/files/quinn_Qd2F4EqIl5KtZdCoJ2m53.mp4",
      STORY:
        "https://www.koskii.com/cdn/shop/files/quinn_RsaQlpBu0uUo5TCoxCHYs.jpg",
      FULL: "https://www.koskii.com/cdn/shop/files/quinn_HtPHseZlKZRbwHElOzbnm.mp4",
    },
  },
  {
    title: "Mauve Swarovski Semi Crepe Designer Saree",
    urls: {
      SHORT:
        "https://www.koskii.com/cdn/shop/files/quinn_xrwczuptre1zumxwhojw2l6i.mp4",
      POSTER:
        "https://www.koskii.com/cdn/shop/files/quinn_rah9aq5f7qbf10va4jlib2e6.jpg",
      STORY:
        "https://www.koskii.com/cdn/shop/files/quinn_t2qz1c68mdof0etwxupvietq.jpg",
      FULL: "https://www.koskii.com/cdn/shop/files/quinn_fu1rf989jagx76xqcjp301jq.mp4",
    },
  },
  {
    title: "Leaf Green Stonework Satin Saree",
    urls: {
      STORY:
        "https://www.koskii.com/cdn/shop/files/quinn_iqp7wgw8n11mgz9ukxyff6uq.jpg",
      SHORT:
        "https://www.koskii.com/cdn/shop/files/quinn_b8nskjdd37lrkx8kk4ol7a19.mp4",
      POSTER:
        "https://www.koskii.com/cdn/shop/files/quinn_ascmdzpfdwumfrsszwdqgnuk.jpg",
      FULL: "https://www.koskii.com/cdn/shop/files/quinn_goydclxjba9rj0n0h2ysrhsn.mp4",
    },
  },
  {
    title: "Turquoise Blue Stonework Satin Saree",
    urls: {
      SHORT:
        "https://www.koskii.com/cdn/shop/files/quinn_zn1zp9mj27yeiq5i0l1tj9mw.mp4",
      POSTER:
        "https://www.koskii.com/cdn/shop/files/quinn_nt1a9g2yoeno3miphz974ihq.jpg",
      STORY:
        "https://www.koskii.com/cdn/shop/files/quinn_q08ikf62eqj2bpi8462r8z0d.jpg",
      FULL: "https://www.koskii.com/cdn/shop/files/quinn_samtp2ot23d4lge0mpczsv36.mp4",
    },
  },
  {
    title: "Rama Green Stonework Georgette Saree",
    urls: {
      POSTER:
        "https://www.koskii.com/cdn/shop/files/quinn_mvu0k95xvotj46ojebkl002o.jpg",
      SHORT:
        "https://www.koskii.com/cdn/shop/files/quinn_hjn1lzik2i5ifakzhxzddhus.mp4",
      STORY:
        "https://www.koskii.com/cdn/shop/files/quinn_znamy4oyb2v3vusn05eyrw7s.jpg",
      FULL: "https://www.koskii.com/cdn/shop/files/quinn_r265h1d6m1snymwt90hsjrwx.mp4",
    },
  },
  {
    title: "Lavender Stonework Chiffon Saree",
    urls: {
      STORY:
        "https://www.koskii.com/cdn/shop/files/quinn_me1ug68cl2i70xt28z76i4u7.jpg",
      FULL: "https://www.koskii.com/cdn/shop/files/quinn_wugl5lxuvmaoauv43l39f98y.mp4",
      POSTER:
        "https://www.koskii.com/cdn/shop/files/quinn_oxog6612rqgieigyivspsmzh.jpg",
      SHORT:
        "https://www.koskii.com/cdn/shop/files/quinn_mht9l3dprfjkyzqy9f6umqbr.mp4",
    },
  },
  {
    title: "Pink Threadwork Chiffon Saree",
    urls: {
      POSTER:
        "https://www.koskii.com/cdn/shop/files/quinn_prnwvkk4lnwk3gzqx2xe2geu.jpg",
      FULL: "https://www.koskii.com/cdn/shop/files/quinn_c22hn5054kp0sjbaxjhxs2ui.mp4",
      STORY:
        "https://www.koskii.com/cdn/shop/files/quinn_a9ejnkmpmedtm5hzww6f2pbk.jpg",
      SHORT:
        "https://www.koskii.com/cdn/shop/files/quinn_v8vmyxmd8pyk9emmd3xhxqw2.mp4",
    },
  },
  {
    title: "Beige Printed Organza Unstitched Salwar Suit",
    urls: {
      FULL: "https://www.koskii.com/cdn/shop/files/quinn_j4rjytdpc1qovp5mze5j5d2m.mp4",
      POSTER:
        "https://www.koskii.com/cdn/shop/files/quinn_geuclgr0noivv266fucle0m3.jpg",
      SHORT:
        "https://www.koskii.com/cdn/shop/files/quinn_ed2jdmhn3944xas086gj4hy3.mp4",
      STORY:
        "https://www.koskii.com/cdn/shop/files/quinn_dco8av16c83ebgh4iyzpx7mm.jpg",
    },
  },
  {
    title: "Red Mirrorwork Georgette Saree",
    urls: {
      POSTER:
        "https://www.koskii.com/cdn/shop/files/quinn_px9vftp8raojnrq549h2myud.jpg",
      FULL: "https://www.koskii.com/cdn/shop/files/quinn_f91vh0vm9gpmkj5jhmsyvg5v.mp4",
      SHORT:
        "https://www.koskii.com/cdn/shop/files/quinn_wvan64cqn0zyxfiwx7rcs4c9.mp4",
      STORY:
        "https://www.koskii.com/cdn/shop/files/quinn_p63dmpg6vhx2tmlhm0yc86bq.jpg",
    },
  },
  {
    title: "Yellow Gotapatti Net Saree",
    urls: {
      SHORT:
        "https://www.koskii.com/cdn/shop/files/quinn_c1trjg9gpg0m4ok8xajzn2ak.mp4",
      POSTER:
        "https://www.koskii.com/cdn/shop/files/quinn_v6zyskl3aj6vs37jrm3yvyhp.jpg",
      STORY:
        "https://www.koskii.com/cdn/shop/files/quinn_hcb5a5l72zbi0c67of8nhhhg.jpg",
      FULL: "https://www.koskii.com/cdn/shop/files/quinn_w4pxxur5fpkxpr78lr18u5q1.mp4",
    },
  },
  {
    title: "Grey Threadwork Tissue Saree",
    urls: {
      STORY:
        "https://www.koskii.com/cdn/shop/files/quinn_sc1wzr4jw34g40sis3j6sea0.jpg",
      SHORT:
        "https://www.koskii.com/cdn/shop/files/quinn_ec9axtncfehhxqwbxem842pq.mp4",
      FULL: "https://www.koskii.com/cdn/shop/files/quinn_wn55i9wg3isqythum8qxswcq.mp4",
      POSTER:
        "https://www.koskii.com/cdn/shop/files/quinn_z2smqxvzslc2ztqz20uu5eiy.jpg",
    },
  },
];

export type CarouselItem = (typeof CAROUSEL_DATA)[number];
