export const INVOICE_DATA = [
  {
    businessName: "Koskii Private limited",
    id: "QUINN-INV-001",
    createdAt: "2025-08-17",
    status: "pending",
    dueDate: "2025-09-17",
    amount: {
      paid: 0,
      beforeTax: 1000,
      tax: 180,
    },
  },
  {
    businessName: "TechPro Solutions Inc",
    id: "QUINN-INV-002",
    createdAt: "2025-08-20",

    status: "partially_paid",
    dueDate: "2025-09-20",
    amount: {
      paid: 1000,
      beforeTax: 2500,
      tax: 450,
    },
  },
  {
    businessName: "Global Retail Partners",
    id: "QUINN-INV-003",
    createdAt: "2025-08-22",
    status: "partially_paid",
    dueDate: "2025-09-22",
    amount: {
      paid: 1500,
      beforeTax: 3750,
      tax: 675,
    },
  },
  {
    businessName: "Innovate Design Studio",
    id: "QUINN-INV-004",
    createdAt: "2025-08-25",

    status: "paid",
    dueDate: "2025-09-25",
    amount: {
      paid: 2124,
      beforeTax: 1800,
      tax: 324,
    },
  },
  {
    businessName: "EcoGreen Solutions Ltd",
    id: "QUINN-INV-005",
    createdAt: "2025-08-28",

    status: "partially_paid",
    dueDate: "2025-09-28",
    amount: {
      paid: 2000,
      beforeTax: 4200,
      tax: 756,
    },
  },
  {
    businessName: "Quantum Computing Labs",
    id: "QUINN-INV-006",
    createdAt: "2025-09-01",

    status: "partially_paid",
    dueDate: "2025-10-01",
    amount: {
      paid: 2500,
      beforeTax: 5500,
      tax: 990,
    },
  },
  {
    businessName: "Artisan Crafts Co",
    id: "QUINN-INV-007",
    createdAt: "2025-09-03",

    status: "paid",
    dueDate: "2025-10-03",
    amount: {
      paid: 944,
      beforeTax: 800,
      tax: 144,
    },
  },
  {
    businessName: "Digital Marketing Pro",
    id: "QUINN-INV-008",
    createdAt: "2025-09-05",

    status: "partially_paid",
    dueDate: "2025-10-05",
    amount: {
      paid: 1000,
      beforeTax: 3200,
      tax: 576,
    },
  },
  {
    businessName: "Smart Home Systems",
    id: "QUINN-INV-009",
    createdAt: "2025-09-08",

    status: "partially_paid",
    dueDate: "2025-10-08",
    amount: {
      paid: 2400,
      beforeTax: 4800,
      tax: 864,
    },
  },
  {
    businessName: "Fresh Foods Market",
    id: "QUINN-INV-010",
    createdAt: "2025-09-10",

    status: "paid",
    dueDate: "2025-10-10",
    amount: {
      paid: 1770,
      beforeTax: 1500,
      tax: 270,
    },
  },
  {
    businessName: "Cloud Services Plus",
    id: "QUINN-INV-011",
    createdAt: "2025-09-12",

    status: "partially_paid",
    dueDate: "2025-10-12",
    amount: {
      paid: 3000,
      beforeTax: 6000,
      tax: 1080,
    },
  },
  {
    businessName: "Urban Fashion Hub",
    id: "QUINN-INV-012",
    createdAt: "2025-09-15",

    status: "partially_paid",
    dueDate: "2025-10-15",
    amount: {
      paid: 1000,
      beforeTax: 2800,
      tax: 504,
    },
  },
  {
    businessName: "Wellness Center Pro",
    id: "QUINN-INV-013",
    createdAt: "2025-09-18",

    status: "paid",
    dueDate: "2025-10-18",
    amount: {
      paid: 4130,
      beforeTax: 3500,
      tax: 630,
    },
  },
  {
    businessName: "Data Analytics Corp",
    id: "QUINN-INV-014",
    createdAt: "2025-09-20",

    status: "partially_paid",
    dueDate: "2025-10-20",
    amount: {
      paid: 2250,
      beforeTax: 4500,
      tax: 810,
    },
  },
  {
    businessName: "Green Energy Solutions",
    id: "QUINN-INV-015",
    createdAt: "2025-09-22",

    status: "partially_paid",
    dueDate: "2025-10-22",
    amount: {
      paid: 2000,
      beforeTax: 5200,
      tax: 936,
    },
  },
  {
    businessName: "Modern Furniture Co",
    id: "QUINN-INV-016",
    createdAt: "2025-09-25",

    status: "paid",
    dueDate: "2025-10-25",
    amount: {
      paid: 4484,
      beforeTax: 3800,
      tax: 684,
    },
  },
  {
    businessName: "Security Systems Ltd",
    id: "QUINN-INV-017",
    createdAt: "2025-09-28",

    status: "partially_paid",
    dueDate: "2025-10-28",
    amount: {
      paid: 2050,
      beforeTax: 4100,
      tax: 738,
    },
  },
  {
    businessName: "Creative Studios Inc",
    id: "QUINN-INV-018",
    createdAt: "2025-10-01",

    status: "partially_paid",
    dueDate: "2025-11-01",
    amount: {
      paid: 1000,
      beforeTax: 2900,
      tax: 522,
    },
  },
  {
    businessName: "Health Foods Direct",
    id: "QUINN-INV-019",
    createdAt: "2025-10-03",

    status: "paid",
    dueDate: "2025-11-03",
    amount: {
      paid: 2242,
      beforeTax: 1900,
      tax: 342,
    },
  },
  {
    businessName: "Tech Education Center",
    id: "QUINN-INV-020",
    createdAt: "2025-10-05",

    status: "partially_paid",
    dueDate: "2025-11-05",
    amount: {
      paid: 1650,
      beforeTax: 3300,
      tax: 594,
    },
  },
  {
    businessName: "Smart Logistics Pro",
    id: "QUINN-INV-021",
    createdAt: "2025-10-08",

    status: "partially_paid",
    dueDate: "2025-11-08",
    amount: {
      paid: 2000,
      beforeTax: 4700,
      tax: 846,
    },
  },
  {
    businessName: "Digital Print Masters",
    id: "QUINN-INV-022",
    createdAt: "2025-10-10",

    status: "paid",
    dueDate: "2025-11-10",
    amount: {
      paid: 2596,
      beforeTax: 2200,
      tax: 396,
    },
  },
  {
    businessName: "Web Solutions Hub",
    id: "QUINN-INV-023",
    createdAt: "2025-10-12",

    status: "partially_paid",
    dueDate: "2025-11-12",
    amount: {
      paid: 1800,
      beforeTax: 3600,
      tax: 648,
    },
  },
  {
    businessName: "Organic Farm Fresh",
    id: "QUINN-INV-024",
    createdAt: "2025-10-15",

    status: "partially_paid",
    dueDate: "2025-11-15",
    amount: {
      paid: 1000,
      beforeTax: 2400,
      tax: 432,
    },
  },
  {
    businessName: "Mobile App Developers",
    id: "QUINN-INV-025",
    createdAt: "2025-10-18",

    status: "paid",
    dueDate: "2025-11-18",
    amount: {
      paid: 6844,
      beforeTax: 5800,
      tax: 1044,
    },
  },
  {
    businessName: "Industrial Solutions Co",
    id: "QUINN-INV-026",
    createdAt: "2025-10-20",

    status: "partially_paid",
    dueDate: "2025-11-20",
    amount: {
      paid: 2450,
      beforeTax: 4900,
      tax: 882,
    },
  },
  {
    businessName: "Fitness Equipment Pro",
    id: "QUINN-INV-027",
    createdAt: "2025-10-22",

    status: "partially_paid",
    dueDate: "2025-11-22",
    amount: {
      paid: 1500,
      beforeTax: 3900,
      tax: 702,
    },
  },
  {
    businessName: "Office Supplies Plus",
    id: "QUINN-INV-028",
    createdAt: "2025-10-25",

    status: "paid",
    dueDate: "2025-11-25",
    amount: {
      paid: 1888,
      beforeTax: 1600,
      tax: 288,
    },
  },
  {
    businessName: "Cloud Infrastructure Ltd",
    id: "QUINN-INV-029",
    createdAt: "2025-10-28",

    status: "partially_paid",
    dueDate: "2025-11-28",
    amount: {
      paid: 3250,
      beforeTax: 6500,
      tax: 1170,
    },
  },
  {
    businessName: "Marketing Analytics Pro",
    id: "QUINN-INV-030",
    createdAt: "2025-10-30",

    status: "pending",
    dueDate: "2025-11-30",
    amount: {
      paid: 0,
      beforeTax: 4300,
      tax: 774,
    },
  },
];
